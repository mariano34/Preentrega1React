import CartasProductos from "./CartasProductos";
import NavBar from "./NavBar";
import "./estilos.css";

import alexaLogo from "./img/alexaLogo.png";
import cortanaLogo from "./img/cortanaLogo.png";
import siriLogo from "./img/siriLogo.png";






function App() {
    return <main>

        <NavBar />


        <div className="contenedorCartas">

            <CartasProductos titulo="Alexa" descripcion="Alexa es una asistente virtual creada por Amazon." imagenes={alexaLogo} />

            <CartasProductos titulo="Cortana" descripcion="Cortana es la asistente virtual de Microsoft." imagenes={cortanaLogo} />

            <CartasProductos titulo="Siri
            " descripcion="Siri es una asistente virtual de Samsung y Apple." imagenes={siriLogo} />


        </div>

    </main>
}



export default App;

