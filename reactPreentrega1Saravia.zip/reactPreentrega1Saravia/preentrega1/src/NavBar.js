
import CartasProductos from "./CartasProductos";

function NavBar(personalizacion) {


    let { imagenes, descripcion, titulo } = personalizacion;

    return <header><nav>

        <h1>Proyecto React</h1>

        <div className="botonesNav ">

            <button className="botonNav">Inicio</button>

            <button className="botonNav">Categorias</button>

            <button className="botonNav">Perfil</button>


        </div>

    </nav>
    </header>
}

export default NavBar;