import { useState } from "react"

function CartasProductos(personalizacion) {

    const [likes, modificarLikes] = useState(0);

    function meGusta() {
        modificarLikes(likes + 1);
    }

    function noMeGusta() {
        if (likes > 0){
            modificarLikes(likes - 1);
    
        }
       
       
       }

    let { imagenes, descripcion, titulo } = personalizacion;

    return <div className="cartasProductos">

        <img className="imagenCarta" src={imagenes} alt="Logos" />
        <h2> {titulo}</h2>

        <span className="descripciones">
            {descripcion}
        </span>

        <span className="likes">Likes {likes}</span>

        <div className="cajaBotones">
            <button onClick={meGusta} className="botonComprar">Like</button>

            <button onClick={noMeGusta} className="boton2">Dislike</button>
        </div>
    </div>
}

export default CartasProductos;
